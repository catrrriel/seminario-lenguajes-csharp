namespace SGE.Aplicacion.Expedientes;
public record class AgregarExpedienteRequest(string Caratula);
